﻿namespace MortgageAPI.Models.DTO
{
    public class LoginRequest
    {
        public string username { get; set; }
        public string password { get; set; }
    }
}
